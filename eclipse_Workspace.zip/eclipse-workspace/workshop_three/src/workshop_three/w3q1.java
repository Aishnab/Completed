package workshop_three;

public class w3q1 {
public static void main(String args[]) {
	int i=0;
	
	for (i=0;i<=10;i++) {
		System.out.println("result:"+i);
	}
}
}

