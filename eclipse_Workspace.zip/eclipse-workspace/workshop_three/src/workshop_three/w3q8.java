package workshop_three;

import java.util.Scanner;

public class w3q8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
        System.out.print("Enter 5 numbers: ");
        int arr[] = new int[5];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = input.nextInt();
        }
        for(int i = 0; i <arr.length; i++) {
            for (int j = 1; j<(arr.length-i); j++) {
                if (arr[j-1] > arr[j]) {
                    int temp = arr[j-1];
                    arr[j-1]  = arr[j];
                    arr[j] = temp;
                }
            }
        }
        
        for (int k = 0; k < arr.length; k++) {
            System.out.print(arr[k] + ",") ;
        }
    }

	}


