package workshop_three;
import java.util.Scanner;
public class w3q12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);

        // Ask the user for the size of the array
        System.out.print("Enter the number of strings: ");
        int size = input.nextInt();
        input.nextLine(); // Consume the newline character

        // Create an array to store the strings
        String strings[] = new String[size];

        // Populate the array with user input
        for (int i = 0; i < size; i++) {
            System.out.print("Enter string #" + (i + 1) + ": ");
            strings[i] = input.nextLine();
        }

        // Concatenate the strings using an enhanced for loop
        String concatenatedString = "";
        for (String str : strings) {
            concatenatedString += str + " ";
        }

        // Print the concatenated string
        System.out.println("Concatenated string: " + concatenatedString);

	}

}
