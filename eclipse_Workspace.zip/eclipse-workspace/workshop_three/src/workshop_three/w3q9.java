package workshop_three;
import java.util.Scanner;
public class w3q9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner input = new Scanner(System.in);
	        
	     System.out.print("Enter a string: ");
	     String a = input.nextLine().toLowerCase(); 
	     char[] characters = a.toCharArray();
	     int vowelCount = 0;
	     for (char character : characters) {
	            if (character == 'a' || character == 'e' || character == 'i' || character == 'o' || character == 'u') {
	                vowelCount++;
	            }
	        }
	     System.out.println("Number of vowels: " + vowelCount);
	     
	}

}
