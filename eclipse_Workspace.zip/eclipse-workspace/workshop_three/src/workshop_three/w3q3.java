package workshop_three;
import java.util.Scanner;
public class w3q3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input= new Scanner(System.in);
		 int n;
		 do {
		     System.out.println("Enter a number:");
		     n = input.nextInt();
		    }
		    while(n!= 0);
		    System.out.println("Out Of the Loop.");
	}

}
