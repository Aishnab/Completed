package workshop_three;
import java.util.Scanner;
public class w3q2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
		Scanner input= new Scanner(System.in);
		System.out.print("Enter a number: ");
		n=input.nextInt();
		int i=1;
		long f=1;
		
		while(i<=n){
			f*=i;
			i++;
			
		}
		System.out.printf("Factorial of %d = %d",n,f);
	}

}
