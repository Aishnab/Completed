package workshop_three;
import java.util.Scanner;

public class w3q7 {
    public static void main(String[] args) {
    	Scanner input = new Scanner(System.in);
        System.out.print("Enter 5 numbers: ");
        int arr[] = new int[5];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = input.nextInt();
        }
        int toFind;
        System.out.print("Number to find in array: ");
        toFind= input.nextInt();
        boolean found = false;

        for (int n : arr) {
          if (n == toFind) {
            found = true;
            break;
          }
        }
        
        if(found)
          System.out.println(toFind + " is found.");
        else
          System.out.println(toFind + " is not found.");
    }
}