package workshop_three;
import java.util.Scanner;
public class w3q5 {
	static void reverse(int a[],int n) {
		int b[]=new int[n];
		int j=n;
		for(int i = 0; i < n; i++) {
			b[j-1]=a[i];
			j -=1;
		}
		System.out.println("Reversed array is:\n");
		for (int k=0;k<n;k++) {
			System.out.println(b[k]);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.print("Enter 5 numbers:");
		int arr[]= new int[5];
		for (int i=0;i<5;i++) {
			arr[i]= input.nextInt();
		}
		reverse(arr,arr.length);
	}
	}


