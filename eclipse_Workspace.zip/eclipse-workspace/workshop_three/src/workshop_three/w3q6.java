package workshop_three;
import java.util.Scanner;

public class w3q6 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter 5 numbers: ");
        double arr[] = new double[5];

        for (int i = 0; i < 5; i++) {
            arr[i] = input.nextDouble();
        }

        double sum = 0;
        for (double num : arr) {
            sum += num;
        }

        double average = sum / arr.length;

        System.out.println("Sum of given array is " + sum);
        System.out.println("Average of given array is " + average);
    }
}
