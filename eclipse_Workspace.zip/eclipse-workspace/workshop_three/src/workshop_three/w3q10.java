package workshop_three;
import java.util.Scanner;
public class w3q10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the number of elements in the array: ");
		int n = input.nextInt();
		double[] arr = new double[n];
		System.out.println("Enter the elements of the array:");
		for (int i = 0; i < n; i++) {
			System.out.print("Element " + (i + 1) + ": ");
			arr[i] = input.nextDouble();
		}
		double max = Double.MIN_VALUE;
		for (double num : arr) {
			if (num > max) {
				max = num;
			}
		}
		System.out.println("The maximum value in the array is: " + max);
		}

}
