package workshop_two;
import java.util.Scanner;
public class codePoint {
public static void main (String args[]) {
	int length;
	int breadth;
	Scanner input = new Scanner(System.in);
	System.out.print("Enter length: ");
	length =input.nextInt();
	System.out.print("Enter breadth: ");
	breadth =input.nextInt();
	if(length==breadth) {
		System.out.println("Its a square.");
	}else {
		System.out.println("Its a rectangle.");
	}
}
}
