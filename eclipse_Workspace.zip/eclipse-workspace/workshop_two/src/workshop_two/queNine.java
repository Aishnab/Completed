package workshop_two;
import java.util.Scanner;

public class queNine {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("Enter grade:");
		String a =input.nextLine();
		switch (a) {
		case "A+":
			System.out.println("Excellent !");
            break;
        case "A":
            System.out.println("Outstanding !");
            break;
        case "B+":
            System.out.println("Good !");
            break;
        case "B":
            System.out.println("Can do better !");
            break;
        case "C+":
            System.out.println("Just Passed !");
            break;
        case "C":
            System.out.println("You Failed !");
            break;
        default:
            System.out.println("Invalid grade!");
		}
	}

}
