package workshop_two;
import java.util.Scanner;
public class queSeven {
public static void main(String args[]) {
	Scanner input=new Scanner(System.in);
	System.out.println("Enter the value of x: ");
	int x=input.nextInt();
	if (x>5 && x<15) {
		System.out.println("The value of x is greater than 5 and less than 15.");
	}else {
		System.out.println("The value of x is not greater than 5 and less than 15.");
	}
}
}
