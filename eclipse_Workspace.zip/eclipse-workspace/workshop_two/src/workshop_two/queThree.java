package workshop_two;

import java.util.Scanner;
public class queThree {
public static void main(String args[]) {
	int a;
	Scanner input= new Scanner(System.in);
	System.out.println("Enter age:");
	a=input.nextInt();
	if (a>=60) {
		System.out.println("You are in your oldage.");
	}else if (a>=30 && a<=59 ) {
		System.out.println("You are in middle age.");
	}else if (a>=18 && a<=29) {
		System.out.println("You are an adult.");
	}else if (a>=13 && a<=17) {
		System.out.println("You are a teenager.");
	}else {
		System.out.println("You are a child.");
	}
}
}