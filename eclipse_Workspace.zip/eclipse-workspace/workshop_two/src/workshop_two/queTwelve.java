package workshop_two;
import java.util.Scanner;

public class queTwelve {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input= new Scanner(System.in);
		System.out.println("Enter a number:");
		int a=input.nextInt();
		long b= a;
		float c=a;
		System.out.println("Converted to long: " + b);
	    System.out.println("Converted to float: " + c);
	}

}
