package workshop_two;
import java.util.Scanner;
public class queFive {
	public static void main(String args[]) {
		Scanner input= new Scanner(System.in);
		System.out.println("Do you have medical condition?:(y/n)");
        String condition = input.nextLine();
        if (condition.equals("y")) {
            System.out.println("You cannot take the exams.");
        }else {
            System.out.println("You may take your exams.");
            
        }
	}
}

      
        
        
