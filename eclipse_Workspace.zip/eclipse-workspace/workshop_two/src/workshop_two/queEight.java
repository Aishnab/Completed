package workshop_two;

public class queEight {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=20,y=15,z=10;
		if(x>y) {
			if (y>z) {
				System.out.println("X is greater than y and z.");
			}
		}else {
			System.out.println("X is less than y.");
		}
	}

}
