package workshop_two;
import java.util.Scanner;
public class queEleven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input= new Scanner(System.in);
		System.out.println("Enter first string:");
		String a= input.nextLine();
		System.out.println("Enter second string:");
		String b = input.nextLine();
		
		System.out.println("Length of first string: " + a.length());
        System.out.println("Length of second string: " + b.length());
        System.out.println("Comparison result: " + a.compareTo(b));
        System.out.println("Character at index 0 of first string: " + a.charAt(0));
        System.out.println("Substring of first string: " + a.substring(0, Math.min(a.length(), 3)));
        System.out.println("Equality check: " + a.equals(b));
        System.out.println("First string in uppercase: " + a.toUpperCase());
        System.out.println("Second string in lowercase: " + b.toLowerCase());
	}

}
