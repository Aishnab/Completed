package workshop_two;
import java.util.Scanner;

public class queFourteen {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("enter a number:");
		float a= input.nextFloat();
		int b=(int)a;
		float c= b;
		System.out.println("Float to int:"+b);
		System.out.println("int to float:"+c);
	}

}
