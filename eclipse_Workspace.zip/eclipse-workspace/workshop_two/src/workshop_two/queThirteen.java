package workshop_two;
import java.util.Scanner;

public class queThirteen {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input=new Scanner(System.in);
		System.out.println("Enter double value:");
		double a= input.nextDouble();
		long b=(long)a;
		int c=(int)a;
		System.out.println("long value:"+b);
		System.out.println("int value:"+c);
		
	}

}
