package tutorial_four;
public class Students{
	    public static void main(String args []) {
	        Student myobj = new Student();
	        myobj.name = "Aishna";
	        myobj.age = 19;
	        myobj.course = "BIT";
	        //System.out.println("His name is " + myobj.name + " his age is " + myobj.age);
	        myobj.printDetails(); // except static we must make a object to call the methods 
	        Student.College(); // we can call static method using class name;;;
	        Student s1= new Student("ram", 22, "BIT");
	    }
	    
	}
	// new class 
	class Student{
	    
	    int age;
	    String name;
	    String course;
	    // methods for 
	    static void College(){
	        System.out.println("Herald");
	        
	    }
	    void printDetails() {

	        System.out.println("My name is " + name +"." +" I am " + age + ". I am studying "+ course +".");
	    }
	    Student(){
	    	System.out.println("This is a constructor.");
	    }
	    
	    Student(String n,int a,String c){
	    	name = n;
	    	age = a;
	    	course = c;
	    	System.out.println("parameter wala constructor.");
	    	System.out.println(n);
	    	System.out.println(a);
	    	System.out.println(c);
	    }

	}




 
 