package tutorial_three;
import java.util.Scanner;
public class Array {
public static void main(String args[]) {
	int size;
	Scanner input=new Scanner(System.in);
	System.out.print("Enter size");
	size=input.nextInt();
	int arr[]=new int[size];
	System.out.print("Enter elements:");
	
    for (int i = 0; i < arr.length; i++) {
        arr[i]=input.nextInt();
    }
    for (int i = 0; i < arr.length; i++) {
    	System.out.println("the result:"+arr[i]);
    }
}
}