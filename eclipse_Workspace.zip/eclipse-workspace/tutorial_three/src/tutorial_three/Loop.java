package tutorial_three;
import java.util.Scanner;
public class Loop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
		Scanner input=new Scanner(System.in);
		System.out.println("Enter the value:");
		n= input.nextInt();
		//for (i=0;i<=n;i++) {
			//if(i%2==0) {
			//	System.out.println("Even"+i);
		//	}
		
		
		//}
		//while(n<10){
			//System.out.println(n);
			//n++;
		//}
		
		//multiply
		//int i=1;
		//while(i<=10) {
			//System.out.println(n+"x"+i+"="+n*i);
			//i++;
		//}
		
		
		
	}

}
