package tutorial_three;

import java.util.Scanner;

public class Arr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int size;
		Scanner input=new Scanner(System.in);
		System.out.print("Enter size:");
		size =input.nextInt();
		
		System.out.print("Enter elements:");
		
		int arr[]=new int [size];
		for (int i=0; i<size; i++) {
			arr[i]=input.nextInt();
		}
		for (int i=0; i<size; i++) {
		System.out.println("array:"+i);
		}
	}

}
