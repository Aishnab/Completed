package tutorial;

import java.util.Scanner;

public class six {
	public static void main (String args[]) {
		double c,f;
		Scanner input= new Scanner(System.in);
		System.out.println("Enter the temperature in celsius:");
		c=input.nextDouble();
		f=c*1.8+32;
		System .out.println("The temperature in fahernheit is:"+f);
	}
}
