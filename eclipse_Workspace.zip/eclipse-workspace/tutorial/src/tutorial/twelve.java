package tutorial;
import java.util.Scanner;
public class twelve {
public static void main(String args[]) {
	double area,pi=3.14;
	int r;
	Scanner input= new Scanner(System.in);
	System.out.println("Enter radius:");
	r=input.nextInt();
	area=pi*Math.pow(r, 2);
	System.out.print("the area of a circle is:"+area);
}
}
