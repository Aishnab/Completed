package tutorial;

import java.util.Scanner;
public class nine {
	public static void main (String args[]) {
		int a, b, add,sub,multiply,divide;
		Scanner input= new Scanner(System.in);
		System.out.println("Enter a number:");
		a=input.nextInt();
		System.out.println("Enter a number:");
		b=input.nextInt();
		add=a+b;
		System.out.println("by adding those numbers we get:"+add);
		sub=a-b;
		System.out.println("by substracting those numbers we get:"+sub);
		multiply=a*b;
		System.out.println("by multiplying those numbers we get:"+multiply);
		divide=a/b;
		System.out.println("by dividing those numbers we get:"+divide);

	}
	
}
