package tutorial;

public class questiontwo {
	public static void main(String args[]) {
		int a= 45;
		int b=32;
		int diff,product;
		diff= a/b;
		product=a*b;
		System.out.println("The differences are:"+diff);
		System.out.println("The products are:"+product);
	}

}
