package tutorial;

import java.util.Scanner;
public class eight {
	public static void main(String args[]) {
		double si,p,r,t;
		Scanner input= new Scanner(System.in);
		System.out.println("Enter the principle amount :");
		p=input.nextDouble();
		System.out.println("Enter the rate of interest :");
		r=input.nextDouble();
		System.out.println("Enter the time period :");
		t=input.nextDouble();
		si=(p*t*r)/100;
		System.out.print("The interest amount is :"+si);
	}
}
