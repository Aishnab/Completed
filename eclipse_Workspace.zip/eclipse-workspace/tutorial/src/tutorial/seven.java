package tutorial;

import java.util.Scanner;
public class seven {
	public static void main(String args[]) {
		int r,h;
		double volume,pi=3.14;
		Scanner input= new Scanner(System.in);
		System.out.println("Enter radius:");
		r=input.nextInt();
		
		System.out.println("Enter height:");
		h=input.nextInt();
		volume=pi*Math.pow(r, 2)*h;
		System.out.println("The volume of a cylinder is:"+volume);
	}
}
