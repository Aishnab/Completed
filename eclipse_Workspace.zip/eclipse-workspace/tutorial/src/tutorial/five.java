package tutorial;

import java.util.Scanner;
public class five {
	public static void main(String args[]) {
		double area, l;
		Scanner input= new Scanner(System.in);
		System.out.println("Enter length:");
		l= input.nextDouble();
		area = Math.pow(l,2);
		System.out.println("The area of square is:"+area);
	}
}
