package tutorial;

import java.util.Scanner;
public class fourteen {
	public static void main(String args[]) {
		double rate,dollar, rupees;
		Scanner input=new Scanner(System.in);
		System.out.println("enter the amount:");
		dollar=input.nextDouble();
		System.out.println("enter the rate:");
		rate=input.nextDouble();
		rupees = dollar * rate;
		System.out.println("The amount in rupees is:"+rupees);
	}

}
