package tutorial;

import java.util.Scanner;
public class eleven {
public static void main(String Args[]) {
	double miles,km;
	Scanner input= new Scanner(System.in);
	System.out.println("Enter the distance:");
	miles=input.nextInt();
	km=miles*1.60;
	System.out.println("The distance in km is:"+km);
}
}
