package tutorial;

public class workshopone {
	public static void main (String args[]) {
		System.out.println("Hey there, I am some data.");
	}

}
