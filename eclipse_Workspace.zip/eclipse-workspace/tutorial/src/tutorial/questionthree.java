package tutorial;

public class questionthree {
	public static void main(String args[]) {
		int num = 3;
		double number = 3.34;
		char letter='a';
		System.out.println("number:"+num);
		System.out.println("Double:"+number);
		System.out .println("Char:"+letter);
		
	}
}
