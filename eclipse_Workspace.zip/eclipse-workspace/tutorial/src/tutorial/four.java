package tutorial;

import java.util.Scanner;
public class four {
	public static void main(String args[]) {
		int base,height;
		double area;
		Scanner input= new Scanner(System.in);
		System.out.println("Enter base:");
		base=input.nextInt();
		System.out.println("Enter height:");
		height=input.nextInt();
		area= (base*height)/2;
		System.out.println("The area of a triangle is:"+area);
	}

}
