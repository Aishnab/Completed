package tutorial;
import java.util.Scanner;
public class thirteen {
	public static void main(String args[]) {
		double quantity,price=20,total;
		Scanner input= new Scanner(System.in);
		System.out.println("Enter quantity:");
		quantity=input.nextDouble();
		total=quantity*price;
		System.out.println("The total cost is:"+total);
	}
}
