package tutorial;
import java.util.Scanner;

public class ten {
public static void main(String args[]) {
	int p,l,b;
	Scanner input= new Scanner(System.in);
	System.out.println("Enter length:");
	l=input.nextInt();
	System.out.println("Enter breadth:");
	b=input.nextInt();
	p = 2*(l+b);
	System.out.println("the perimeter of rectangle is:"+p);
}

}
