package viva;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class signup extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField firstname;
	private JTextField lastname;
	private JTextField email;
	private JTextField username;
	private JPasswordField password;
	private JPasswordField cpassword;
	private JComboBox comboBox;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					signup frame = new signup();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public signup() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 979, 537);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Signup");
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 20));
		lblNewLabel.setBounds(441, 0, 238, 56);
		contentPane.add(lblNewLabel);
		
		JLabel IblNewLabel = new JLabel("First Name");
		IblNewLabel.setFont(new Font("Arial", Font.PLAIN, 15));
		IblNewLabel.setBounds(224, 76, 162, 40);
		contentPane.add(IblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("Last Name");
		lblNewLabel_2.setFont(new Font("Arial", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(224, 126, 170, 40);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Email");
		lblNewLabel_3.setFont(new Font("Arial", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(224, 176, 152, 33);
		contentPane.add(lblNewLabel_3);
		
		firstname = new JTextField();
		firstname.setBounds(390, 88, 238, 28);
		contentPane.add(firstname);
		firstname.setColumns(10);
		
		lastname = new JTextField();
		lastname.setBounds(390, 129, 238, 33);
		contentPane.add(lastname);
		lastname.setColumns(10);
		
		email = new JTextField();
		email.setBounds(390, 176, 238, 33);
		contentPane.add(email);
		email.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Username");
		lblNewLabel_4.setFont(new Font("Arial", Font.PLAIN, 15));
		lblNewLabel_4.setBounds(224, 219, 162, 28);
		contentPane.add(lblNewLabel_4);
		
		username = new JTextField();
		username.setBounds(390, 219, 238, 33);
		contentPane.add(username);
		username.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Password");
		lblNewLabel_5.setFont(new Font("Arial", Font.PLAIN, 15));
		lblNewLabel_5.setBounds(224, 266, 162, 32);
		contentPane.add(lblNewLabel_5);
		
		password = new JPasswordField();
		password.setBounds(390, 265, 238, 33);
		contentPane.add(password);
		
		JButton btnNewButton = new JButton("Sign Up");
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Firstname = firstname.getText();
				String Lastname = lastname.getText();
				String Email = email.getText();
				String Password = password.getText();
				String Cpassword = cpassword.getText();
				String Combobox = (String) comboBox.getSelectedItem();
				
				String regexE = "[a-zA-Z_]+[a-zA-Z0-9_.]+[@][a-z]+[.][a-z]{2,}";
				Pattern EMail =Pattern.compile(regexE);
				
				Matcher EMAIL= EMail.matcher(Email);
				boolean EMAIL1= EMAIL.matches();
				
				if(!Firstname.equals("") && !Email.equals("") && Password.equals(Cpassword)) {
					System.out.println("hello");
					if(EMAIL1==true) {
						try {
							String url ="jdbc:mysql://localhost:3306";
							String username ="root";
							String password ="";
							System.out.println("Hii");
							
							Connection conn = DriverManager.getConnection(url,username,password);
							Statement stm = conn.createStatement();
							
							String query="insert into coursemanagement.student values('"+Firstname+"','"+Lastname+"','"+Email+"','"+Password+"')";
							//String query="insert into coursemanagement.student values('Aishna'+'Bajracharya'+ 'aish12'+ '123@aish'+'bajraishna@gamil.com')";
							
							System.out.println("connection Successful");

							stm.execute(query);
							
							conn.close();
							
							
						}
						catch (Exception ee) {
							System.out.println(ee);
							ee.printStackTrace();
							
						}
					
						JOptionPane.showMessageDialog(null,"Signup Success!");
					}
					else {
						JOptionPane.showMessageDialog(null,"Email invalid.");
					}
					
				}
				
				System.out.println(Firstname);
				System.out.println(Lastname);
				System.out.println(Email);
				System.out.println(Password);
				System.out.println(Cpassword);
				System.out.println(Combobox);
			
				Login l = new Login();
				l.setVisible(true); // page link
				
				dispose(); // existing page nikalne
			}
		});
		btnNewButton.setFont(new Font("Arial", Font.PLAIN, 15));
		btnNewButton.setBounds(571, 435, 108, 28);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_6 = new JLabel("Confirm Password");
		lblNewLabel_6.setFont(new Font("Arial", Font.PLAIN, 15));
		lblNewLabel_6.setBounds(224, 308, 162, 28);
		contentPane.add(lblNewLabel_6);
		
		cpassword = new JPasswordField();
		cpassword.setBounds(390, 308, 238, 33);
		contentPane.add(cpassword);
		
	    comboBox = new JComboBox();
		comboBox.setFont(new Font("Arial", Font.PLAIN, 15));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"--Select Option--", "Admin", "Teacher", "Student"}));
		comboBox.setBounds(394, 363, 232, 28);
		contentPane.add(comboBox);
		
		JLabel lblNewLabel_7 = new JLabel("Select Mode");
		lblNewLabel_7.setFont(new Font("Arial", Font.PLAIN, 15));
		lblNewLabel_7.setBounds(224, 372, 126, 19);
		contentPane.add(lblNewLabel_7);
		
		JButton btnSignUp = new JButton("Log in");
		btnSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login l = new Login();
				l.setVisible(true); // page link
				
				dispose(); // existing page nikalne
			}
		});
		btnSignUp.setFont(new Font("Arial", Font.PLAIN, 15));
		btnSignUp.setBackground(Color.WHITE);
		btnSignUp.setBounds(189, 435, 108, 28);
		contentPane.add(btnSignUp);
	}
}
