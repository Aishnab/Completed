/**
 * 
 */
/**
 * 
 */
module viva {
	requires java.desktop;
	requires java.sql;
}