package AssessedTask;
import akka.actor.AbstractActor;
import akka.actor.ActorSelection;

import java.util.Random;

public class Producer extends AbstractActor {
    private final ActorSelection supervisor;

    public Producer() {
        supervisor = getContext().actorSelection("/user/supervisor");
    }

    @Override
    public Receive createReceive() {
        return receiveBuilder()
                .match(StartProducing.class, msg -> {
                    Random random = new Random();
                    for (int i = 0; i < 1000; i++) {
                        long number = 10000 + random.nextInt(90001);
                        supervisor.tell(number, getSelf());
                    }
                })
                .match(PrimeMessage.class, primeMessage -> {
                    System.out.println(primeMessage.getMessage());
                })
                .build();
    }
}
