package AssessedTask;

public class PrimeMessage {
    private final String message;

    public PrimeMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}

