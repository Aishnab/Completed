package AssessedTask;
import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import akka.actor.Props;

public class Main {

    public static void main(String[] args) {
        ActorSystem system = ActorSystem.create("PrimeNumberSystem");

        ActorRef producer = system.actorOf(Props.create(Producer.class), "producer");
        ActorRef supervisor = system.actorOf(Props.create(Supervisor.class, 10, producer), "supervisor");

        producer.tell(new StartProducing(), ActorRef.noSender());
    }
}