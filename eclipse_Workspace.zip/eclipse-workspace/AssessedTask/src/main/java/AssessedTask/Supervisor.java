package AssessedTask;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.actor.Props;

import java.util.ArrayList;
import java.util.List;

public class Supervisor extends AbstractActor {
    private final List<ActorRef> workers = new ArrayList<>();
    private int currentIndex = 0;
    private final ActorRef producer;

    public Supervisor(int workerCount, ActorRef producer) {
        this.producer = producer;
        for (int i = 0; i < workerCount; i++) {
            workers.add(getContext().actorOf(Props.create(worker.class, "worker-" + i), "worker-" + i));
        }
    }

    @Override
    public Receive createReceive() {
        return receiveBuilder()
                .match(Long.class, number -> {
                    ActorRef worker = workers.get(currentIndex);
                    currentIndex = (currentIndex + 1) % workers.size();
                    worker.forward(number, getContext());
                })
                .build();
    }
}
