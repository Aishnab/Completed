package tutorial_five;

class Parent{
	String name;
public void showP(){
		System.out.println("inParent class");
	}
}

class child extends Parent{
public void showC() {
		System.out.println("inChild Class");
	}
}
class child2 extends Parent{
public void showC2() {
	System.out.println("inChild2 Class");
}
	}

public class inheritance{
	public static void main(String args[]) {
		Parent P1 = new Parent();
		P1.showP();
		
		child c1 = new child();
		c1.showC();
		c1.showP();
		
		child2 c2 = new child2();
		c2.showC2();
		c2.showP();
	}
}
