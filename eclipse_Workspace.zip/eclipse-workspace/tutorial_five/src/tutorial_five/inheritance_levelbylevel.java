package tutorial_five;

class GrandParent{
public void showGP(){
		System.out.println("inGrandParent class");
	}
}

class Parent extends GrandParent{
public void showP() {
		System.out.println("inParent Class");
	}
}
class Child extends Parent{
public void showC() {
	System.out.println("inChild Class");
}
	}

public class inheritance_levelbylevel {
	public static void main(String args[]) {
		GrandParent GP1 = new GrandParent();
		GP1.showGP();
		
		Parent P1 = new Parent();
		P1.showGP();
		P1.showP();
		
		Child C1 = new Child();
		C1.showC();
		C1.showGP();
		C1.showP();
	}
}
