package tutorial_five;

class Parent{

public void showP(){
		System.out.println("inParent class");
	}
Parent(){
	System.out.println("A");
}
}

class child extends Parent{
public void showC() {
		System.out.println("inChild Class");
	}
child(){
	System.out.println("B");
}
}
public class Constructor{

	public static void main(String args[]) {
		Parent P1 = new Parent();
		P1.showP();
		
		child c1 = new child();
		c1.showC();
		c1.showP();
		
	}
}




















