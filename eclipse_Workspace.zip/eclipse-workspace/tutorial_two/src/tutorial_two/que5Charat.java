package tutorial_two;

public class que5Charat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name = "java";
		char a = name.charAt(2);
		System.out.println("Character at index 2: " + a);
	}

}
