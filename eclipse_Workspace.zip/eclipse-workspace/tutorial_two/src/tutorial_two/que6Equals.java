package tutorial_two;

public class que6Equals {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "hello";
		String s2 = "hello";
		String s3 = "harry";
		String s4 = "nepal";

		boolean e1 = s1.equals(s2);
		boolean e2 = s1.equals(s3);
		boolean e3 = s1.equals(s4);

		System.out.println("Equals s1 and s2: " + e1);
		System.out.println("Equals s1 and s3: " + e2);
		System.out.println("Equals s1 and s4: " + e3);

	}

}
