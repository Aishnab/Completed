package tutorial_two;

public class queTwo {
public static void main(String args[]) {
	int a=50,b=40;
	a++;
	b--;
	System.out.println("a after increase:"+a);
	System.out.println("b after increase:"+b);
}
}
