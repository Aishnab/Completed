package tutorial_two;
import java.util.Scanner;
public class name {

	public static void main(String[] args) {
		String firstName;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter your first name:");
		firstName= scan.nextLine();
		if (firstName.length()<4) {
			System.out.print("Your name is too short.");
		}
		else {
			System.out.print("your name is your username.");
		}
	}
}
