package tutorial_two;

public class que5Length {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "Herald College";
		String s2 = "It is located in Naxal Kathmandu";

		int l1 = s1.length();
		int l2 = s2.length();

		System.out.println("Length of s1: " + l1);
		System.out.println("Length of s2: " + l2);

	}
}
