package tutorial_two;

public class que5Concat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "Herald College";
		String s2 = "is located in Naxal Kathmandu";

		String result = s1.concat(s2);
		System.out.println("Concatenated Result is: " + result);

	}

}
