package tutorial_two;

public class queFour {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean  expr1 = (5>3), expr2 = (8>5);
		boolean expr3 = (5>3), expr4 = (2>5);
		boolean expr5 = (!(5==10));
		
		boolean logicalAnd = expr1 && expr2;
		boolean logicalOr = expr3 || expr4;
		boolean logicalNot = !expr5;
		
		System.out.println("Logical AND result: "+logicalAnd);
		System.out.println("Logical OR result: "+logicalOr);
		System.out.println("Logical NOT result"+logicalNot);
	}

}
