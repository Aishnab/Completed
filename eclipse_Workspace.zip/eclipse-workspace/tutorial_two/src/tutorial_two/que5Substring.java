package tutorial_two;

public class que5Substring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name = "Bachelors";
		String a = name.substring(0, 4);
		System.out.println("Substring result: " + a);

	}

}
