package tutorial_two;

import java.util.Scanner;

public class marks {

	public static void main(String[] args) {
		float num;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter Marks:");
		num= scan.nextFloat();
		if (num>=80) {
			System.out.println("dis");
		}
		else if(num<80 && num>=40) {
			System.out.println("1stdiv");
		}
		else {
			System.out.println("fail");
		}
	}
}