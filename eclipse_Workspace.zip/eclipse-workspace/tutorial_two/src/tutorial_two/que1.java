package tutorial_two;

public class que1 {
	public static void main(String args[]) {
		int num = 2345;
		int result=(((num+8)/3)%5)*5;
		System.out.println("Final result:"+result);
		}
}
