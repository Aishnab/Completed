package tutorial_two;
import java.util.Scanner;
public class queSix {

	public static void main(String[] args) {
		// TODO Auto-generated method 
		Scanner input = new Scanner(System.in);
		System.out.print("Enter your age: ");
		int age = input.nextInt();
		if (age >= 18) {
			System.out.println("You are eligible to vote!");
			} else {
				System.out.println("You are not eligible to vote yet.");
		      }
	}

}
