package tutorial_two;

public class queThree {
public static void main(String args[]) {
	int a=40, b=25;
	a/=2;
	b%=2;
	System.out.println("The value of a is:"+a);
	System.out.println("The value of b:"+b);
}
}
