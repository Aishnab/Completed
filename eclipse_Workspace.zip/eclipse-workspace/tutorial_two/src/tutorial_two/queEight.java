package tutorial_two;
import java.util.Scanner;

public class queEight {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the marks obtained: ");
		int num = input.nextInt();
		if (num < 50) {
			System.out.println("Fail");
			} else if (num >= 50 && num < 60) {
				System.out.println("C grade");
		        } else if (num >= 60 && num < 70) {
		        	System.out.println("B grade");
		        } else {
		            System.out.println("A grade");
		        }
	}

}
