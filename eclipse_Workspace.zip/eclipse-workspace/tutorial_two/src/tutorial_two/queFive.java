package tutorial_two;

public class queFive {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "hello";
		String s2 = "hello";
		String s3 = "harry";
		String s4 = "nepal";
		String s5 = "flag";
		String s6 = "";

		int c1 = s1.compareTo(s2);
		int c2 = s1.compareTo(s3);
		int c3 = s1.compareTo(s4);
		int c4 = s1.compareTo(s5);
		int c5 = s1.compareTo(s6);

		System.out.println("Compare s1 and s2: " + c1);
		System.out.println("Compare s1 and s3: " + c2);
		System.out.println("Compare s1 and s4: " + c3);
		System.out.println("Compare s1 and s5: " + c4);
		System.out.println("Compare s1 and s6: " + c5);
	}
}
