package tutorial_two;
import java.util.Scanner;
public class operator {
public static void main(String args[]) {
	int num;
	Scanner scan =new Scanner(System.in);
	System.out.println("Enter a Number:");
	num= scan.nextInt();
	if (num<0) {
		System.out.println("The number is negative.");
	}
	else if(num>0) {
		System.out.println("The number is positive.");
	}
	else {
		System.out.println("The number is 0.");
	}
}
}
