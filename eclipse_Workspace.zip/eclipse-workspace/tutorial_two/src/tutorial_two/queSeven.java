package tutorial_two;
import java.util.Scanner;
public class queSeven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner a = new Scanner(System.in);
		System.out.print("Enter the first number: ");
		double n1 = a.nextDouble();
		System.out.print("Enter the second number: ");
		double n2 = a.nextDouble();
		if (n1 > n2) {
			System.out.println("The greatest number is: " + n1);
			} else if (n2 > n1) {
			System.out.println("The greatest number is: " + n2);
			} else {
			System.out.println("Both numbers are equal.");
			}
		}

	}

