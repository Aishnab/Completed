package tutorial_two;
import java.util.Scanner;
public class email {
	  public static void main(String[] args) {
	        Scanner input = new Scanner(System.in);
	        System.out.print("Enter your email: ");
	        String email = input.nextLine();
	        if (email.contains("@") && email.contains(".")) {
	            if (email.startsWith("np")) {
	                if (email.endsWith(".np")) {
	                    System.out.println("You have a valid email address: " + email);
	                } else {
	                    System.out.println("Your email does not end with '.np'.");
	                }
	            } else {
	                System.out.println("Your email does not start with 'np'.");
	            }
	        } else {
	            System.out.println("Your email does not have '@' and '.'.");
	        }
	        input.close();
	    }
	  
	}

