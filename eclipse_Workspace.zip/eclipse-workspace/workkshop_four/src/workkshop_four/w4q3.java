package workkshop_four;

public class w4q3 {
	  boolean isOn;

	  w4q3() {
	    isOn = false; 
	  }

	  void turnOn() {
	    isOn = true;
	    System.out.println("Light on? " + isOn);
	  }

	  void turnOff() {
	    isOn = false;
	    System.out.println("Light on? " + isOn);
	  }

	  public static void main(String[] args) {

	    w4q3 led = new w4q3();
	    w4q3 halogen = new w4q3();

	    led.turnOn();

	    halogen.turnOff();
	  }
	}



