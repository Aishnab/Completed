package workkshop_four;

public class w4q5 {
	        int accountNumber;
	        String accountHolderName;
	        double balance;

	        // parameterized constructor
	        w4q5(int accountNumber, String accountHolderName, double balance) {
	            this.accountNumber = accountNumber;
	            this.accountHolderName = accountHolderName;
	            this.balance = balance;
	        }

	        // method to display account details
	        void displayAccountDetails() {
	            System.out.println("Account Number: " + accountNumber);
	            System.out.println("Account Holder Name: " + accountHolderName);
	            System.out.println("Balance: " + balance);
	        }

	        public static void main(String[] args) {
	            // create an object of BankAccount using parameterized constructor
	            w4q5 account = new w4q5(123456, "Sita", 10000.0);

	            // display account details
	            account.displayAccountDetails();
	        }
	    }

