package workkshop_four;

public class w4q2 {

	    private String accountNumber;
	    private double balance;
	    private String accountHolderName;
	    private String accountHolderAddress;

	    public w4q2(String accountNumber, double balance, String accountHolderName, String accountHolderAddress) {
	        this.accountNumber = accountNumber;
	        this.balance = balance;
	        this.accountHolderName = accountHolderName;
	        this.accountHolderAddress = accountHolderAddress;
	    }

	    public String getAccountNumber() {
	        return accountNumber;
	    }

	    public void setAccountNumber(String accountNumber) {
	        this.accountNumber = accountNumber;
	    }

	    public double getBalance() {
	        return balance;
	    }

	    public void setBalance(double balance) {
	        this.balance = balance;
	    }

	    public String getAccountHolderName() {
	        return accountHolderName;
	    }

	    public void setAccountHolderName(String accountHolderName) {
	        this.accountHolderName = accountHolderName;
	    }

	    public String getAccountHolderAddress() {
	        return accountHolderAddress;
	    }

	    public void setAccountHolderAddress(String accountHolderAddress) {
	        this.accountHolderAddress = accountHolderAddress;
	    }

	    public void depositMoney(double amount) {
	        balance += amount;
	        System.out.println("Deposited: RS" + amount);
	        System.out.println("Current Balance: RS" + balance);
	    }

	    public void withdrawMoney(double amount) {
	        if (balance < amount) {
	            System.out.println("Insufficient balance");
	        } else {
	            balance -= amount;
	            System.out.println("Withdrawn: RS" + amount);
	            System.out.println("Current Balance: RS" + balance);
	        }
	    }

	    public static void main(String[] args) {
	        w4q2 myAccount = new w4q2("123456789", 100000, "Ram", "Jhapa");

	        System.out.println("Account Number: " + myAccount.getAccountNumber());
	        System.out.println("Balance: RS" + myAccount.getBalance());
	        System.out.println("Account Holder Name: " + myAccount.getAccountHolderName());
	        System.out.println("Account Holder Address: " + myAccount.getAccountHolderAddress());

	        myAccount.depositMoney(50000);

	        myAccount.withdrawMoney(20000);
	    }
	}


