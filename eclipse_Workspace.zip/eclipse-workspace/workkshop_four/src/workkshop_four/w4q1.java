package workkshop_four;

public class w4q1 {
	    private String accountNumber;
	    private double balance;
	    private String accountHolderName;
	    private String accountHolderAddress;

	    public w4q1(String accountNumber, double balance, String accountHolderName, String accountHolderAddress) {
	        this.accountNumber = accountNumber;
	        this.balance = balance;
	        this.accountHolderName = accountHolderName;
	        this.accountHolderAddress = accountHolderAddress;
	    }

	    public String getAccountNumber() {
	        return accountNumber;
	    }

	    public void setAccountNumber(String accountNumber) {
	        this.accountNumber = accountNumber;
	    }

	    public double getBalance() {
	        return balance;
	    }

	    public void setBalance(double balance) {
	        this.balance = balance;
	    }

	    public String getAccountHolderName() {
	        return accountHolderName;
	    }

	    public void setAccountHolderName(String accountHolderName) {
	        this.accountHolderName = accountHolderName;
	    }

	    public String getAccountHolderAddress() {
	        return accountHolderAddress;
	    }

	    public void setAccountHolderAddress(String accountHolderAddress) {
	        this.accountHolderAddress = accountHolderAddress;
	    }

	 public static void main(String[] args) {
	        w4q1 myAccount = new w4q1("123456790", 100000, "Aishna", "Lalitpur");

	        
	        System.out.println("Account Number: " + myAccount.getAccountNumber());
	        System.out.println("Balance: RS" + myAccount.getBalance());
	        System.out.println("Account Holder Name: " + myAccount.getAccountHolderName());
	        System.out.println("Account Holder Address: " + myAccount.getAccountHolderAddress());
	    }
	}


