/**
 * 
 */
/**
 * 
 */
module tutorial_nine {
	requires java.desktop;
}