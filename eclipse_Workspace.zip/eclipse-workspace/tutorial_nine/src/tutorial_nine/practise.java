package tutorial_nine;
import java.util.*;

public class practise {
	public static void main (String args[]) {
		ArrayList<String> al=new ArrayList<>();
//		ArrayList<String> al1=new ArrayList<>();
		al.add("Datengi");
		al.add("Kenab");
		al.add("Aysuhma");
		al.add(1,"Abhishek");
//		// System.out.println(al.size());
//		System.out.println(al);
//		al.remove(2);
//		System.out.println(al);
//		al1.add("Akrit");
//		al1.add("Aishna");
//		al1.add("Barun");
//		System.out.println(al1);
//      //al.addAll(al1);
//		al.addAll(1,al1);
//		System.out.println(al);
		
//		//for loop
//		for (int i = 0;i < al.size();i++) {
//			System.out.println(al.get(i));
//		}
//		
//		//for each loop
//		for (String a:al) { 
//			System.out.println(a);
//		}
		
		// Iterator
		Iterator itr = al.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
	}
}
