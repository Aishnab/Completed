package tutorial_nine;
import java.util.*;
public class q2 {
public static void main(String args[]) {
	LinkedList<String> a = new LinkedList<>();
	
}
}
