package tutorial_nine;
import java.util.*;
public class q1 {
	 public static void main(String[] args) {
	        ArrayList<String> students = new ArrayList<>();

	        students.add("Alice");
	        students.add("Bob");
	        students.add("Charlie");

	        System.out.println("Initial list of students:"+students);

	        students.remove("Bob");

	        System.out.println("\nList of students after removing one:"+students);

	        students.add("David");

	        System.out.println("\nFinal list of students:"+students);
	    }
}
