package tutorial_nine;

import java.util.*;

public class pr3 {
	public static void main (String args[]) {
//		Stack<Integer> s=new Stack<>();
//		s.push(5);
//		s.push(1);
//		s.push(3);
//		s.push(10);
//		System.out.println(s);
//		System.out.println(s.peek());
//		s.pop();
//		System.out.println(s);
		
		
//		Queue<Integer> s = new LinkedList();
//		s.offer(5);
//		s.offer(1);
//		s.offer(3);
//		s.offer(10);
//		System.out.println(s);
//		System.out.println(s.peek());
//		s.poll();
//		System.out.println(s);
		
		
//		Queue<String> s = new PriorityQueue();
//		s.offer("Aish");
//		s.offer("ayush");
//		s.offer("prani");
//		s.offer("sne");
//		System.out.println(s);
//		System.out.println(s.peek());
//		s.poll();
//		System.out.println(s);
		
		
		
//		Queue<Integer> s = new PriorityQueue(Comparator.reverseOrder());
//		s.offer(5);
//		s.offer(1);
//		s.offer(3);
//		s.offer(10);
//		System.out.println(s);
//		System.out.println(s.peek());
//		s.poll();
//		System.out.println(s);
		
		
		Deque<Integer> s = new ArrayDeque();
		s.offer(5);
		s.offer(1);
		s.offer(3);
		s.offer(10);
		System.out.println(s);
		//System.out.println(s.peek());
		s.pollLast();
		System.out.println(s);
		
	}
}
