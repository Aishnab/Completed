package akka;

public class SubMessage {
	int x;
	int y;
	
	SubMessage(int x, int y){
		this.x = x;
		this.y = y;
	}
}
