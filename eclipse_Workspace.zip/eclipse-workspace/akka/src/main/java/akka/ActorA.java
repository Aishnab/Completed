package akka;

import akka.actor.AbstractActor;

public class ActorA extends AbstractActor{

	@Override
	public Receive createReceive() {
		// TODO Auto-generated method stub
		return receiveBuilder()
				.match(String.class, s->{System.out.println("Hello "+s);})
				.match(Integer.class, s->{System.out.println("Executing Task "+s);})
				.match(SumMessage.class, this::onSumMesssage)
				.match(SubMessage.class, this::onSubMesssage)
				.build();
	}
	
	void onSumMesssage(SumMessage ob) {
		System.out.println("Sum of two numbers = "+(ob.x+ob.y));
	}

	void onSubMesssage(SubMessage ob) {
		System.out.println("Difference of two numbers = "+(ob.x-ob.y));
	}
}
