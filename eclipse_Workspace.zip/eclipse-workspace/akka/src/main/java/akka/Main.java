package akka;

import akka.actor.ActorSystem;
import akka.actor.Props;
import akka.actor.ActorRef;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ActorSystem system = ActorSystem.create();
		ActorRef actor1 = system.actorOf(Props.create(ActorA.class));
		actor1.tell(new SubMessage(10,20), actor1);
	}
		
		
	}


