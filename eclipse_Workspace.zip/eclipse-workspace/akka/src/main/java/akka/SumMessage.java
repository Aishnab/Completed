package akka;

public class SumMessage {
	int x;
	int y;
	
	SumMessage(int x, int y){
		this.x = x;
		this.y = y;
	}
}