package workshop9;
import java.util.*;


public class que4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 LinkedList<String> a = new LinkedList<String>();
		    a.add("Red");
		    a.add("Green");
		    a.add("Blue");
		    a.add("Yellow");
		    a.add("Orange");

		    // Iterate and print all the colors
		    System.out.println("All colors in the list:");
		    for (String color : a) {
		      System.out.println(color);
		    }

		    // Check if "Red" exists in the linkedList or not
		    if (a.contains("Red")) {
		      System.out.println("The list contains Red.");
		    } else {
		      System.out.println("The list does not contain Red.");
		    }

		    // Shuffle the elements of the list and print them
		    Collections.shuffle(a);
		    System.out.println("Shuffled colors: " + a);

		    // Print the LinkedList in ascending order
		    Collections.sort(a);
		    System.out.println("Colors in ascending order: " + a);
	}

}
