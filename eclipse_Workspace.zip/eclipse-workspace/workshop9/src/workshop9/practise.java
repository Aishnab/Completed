package workshop9;
import java.util.*;
public class practise {
public static void main(String args[] ) {
//	Set<Integer>s=new HashSet <>();
//	 s.add(5);
//	 s.add(2);
//	 s.add(1);
//	 s.add(10);
//	 s.add(3);
//	 s.add(0);
//	 s.add(100);
//	 System.out.println(s);
	
//	Set<Object> s = new TreeSet<>();
//  s.add("Harry");
//  s.add("Hermoine");
//  s.add("Ron");
//  
//  s.add("Ayushma");
//  s.add("Ayush");
//  s.add("Hi");
//  System.out.println(s);
	
//	// map
//	Map<String,Integer> m= new HashMap<>();
//	m.put("niraj", 986020583);
//	m.put("kenab", 984563832);
//	m.put("Datengi", 987839274);
//	m.put("sosal", 983863940);
//	System.out.println(m);
//	for(Map.Entry<String,Integer> e :m.entrySet()) {
//		System.out.println(e.getKey());
//	}
	
	
	Map<String,Integer> m= new TreeMap<>();
	m.put("niraj", 986020583);
	m.put("kenab", 984563832);
	m.put("Datengi", 987839274);
	m.put("sosal", 983863940);
	System.out.println(m);
	for(Map.Entry<String,Integer> e :m.entrySet()) {
		//System.out.println(e.getKey());
		System.out.println(e);
	}
}
}
