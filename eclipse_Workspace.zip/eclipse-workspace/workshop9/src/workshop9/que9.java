package workshop9;
import java.util.*;

public class que9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<String> s1 = new HashSet<String>();
	    s1.add("Dog");
	    s1.add("Cat");
	    s1.add("Elephant");
	    s1.add("Lion");

	    Set<String> s2 = new HashSet<String>();
	    s2.add("Cat");
	    s2.add("Giraffe");
	    s2.add("Dog");
	    s2.add("Monkey");

	    // Print the original sets
	    System.out.println("Set1: " + s1);
	    System.out.println("Set2: " + s2);

	    // Perform union of set1 and set2
	    Set<String> union = performUnion(s1, s2);
	    System.out.println("Union of set1 and set2: " + union);

	    // Perform intersection of set1 and set2
	    Set<String> intersection = performIntersection(s1, s2);
	    System.out.println("Intersection of set1 and set2: " + intersection);

	    // Perform difference of set1 from set2
	    Set<String> difference = performDifference(s1, s2);
	    System.out.println("Difference of set1 from set2: " + difference);
	  }

	  public static Set<String> performUnion(Set<String> s1, Set<String> s2) {
	    Set<String> union = new HashSet<String>(s1);
	    union.addAll(s2);
	    return union;
	  }

	  public static Set<String> performIntersection(Set<String> s1, Set<String> s2) {
	    Set<String> intersection = new HashSet<String>(s1);
	    intersection.retainAll(s2);
	    return intersection;
	  }

	  public static Set<String> performDifference(Set<String> s1, Set<String> s2) {
	    Set<String> difference = new HashSet<String>(s1);
	    difference.removeAll(s2);
	    return difference;
	}

}
