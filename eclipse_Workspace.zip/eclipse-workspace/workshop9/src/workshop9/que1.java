package workshop9;

import java.util.*;

public class que1 {
public static void main(String args[]) {
	ArrayList<String> a=new ArrayList<>();
	a.add("Aishna");
	a.add("Ayushma");
	a.add("Abha");
	a.add("Sam");
	System.out.println(a);
	a.remove(2);
	System.out.println(a);
	
}
}
