package workshop9;

import java.util.*;

public class que3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 ArrayList<Integer> l = new ArrayList<Integer>();
		    l.add(1);
		    l.add(2);
		    l.add(3);
		    l.add(4);
		    l.add(5);
		    System.out.println("Initial list: " + l);
		    Collections.rotate(l, 2);
		    System.out.println("List after rotating by 2 positions: " + l);
	}

}
