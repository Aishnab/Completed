package workshop9;
import java.util.*;
public class que14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	    ArrayList<Integer> num = new ArrayList<Integer>();
	    num.add(5);
	    num.add(3);
	    num.add(8);
	    num.add(4);
	    num.add(2);

	    System.out.println("Original list of numbers: " + num);

	    // Sort the list in ascending order
	    Collections.sort(num);
	    System.out.println("List sorted in ascending order: " + num);

	    // Perform binary search on the list
	    int index = Collections.binarySearch(num, 4);
	    if (index >= 0) {
	      System.out.println("Element found at index " + index);
	    } else {
	      System.out.println("Element not found");
	    }
	}

}
