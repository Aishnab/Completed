package workshop9;

import java.util.*;

public class que2 {
public static void main(String args[]) {
	 LinkedList<String> a = new LinkedList<String>();

	    // Check if the linked list is empty
	    if (a.isEmpty()) {
	      System.out.println("The linked list is empty.");
	    } else {
	      System.out.println("The linked list is not empty.");
	    }

	    // Add elements to the linked list
	    a.addFirst("element1");
	    a.addLast("element2");

	    // Print the linked list
	    System.out.println("Linked list after adding elements: " + a);
}
}
