package workshop9;
import java.util.*;
public class que5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack<String> stack = new Stack<String>();

	    // Push the tasks "Read", "Write", and "Code" onto the stack
	    stack.push("Read");
	    stack.push("Write");
	    stack.push("Code");

	    // Pop a task from the stack
	    String a = stack.pop();
	    System.out.println("Popped task: " + a);

	    // Push tasks "Debug" and "Test" onto the stack
	    stack.push("Debug");
	    stack.push("Test");

	    // Peek at the top task without removing it
	    String b = stack.peek();
	    System.out.println("Top task: " + b);

	    // Print the stack
	    System.out.println("Stack: " + stack);
	}

}
