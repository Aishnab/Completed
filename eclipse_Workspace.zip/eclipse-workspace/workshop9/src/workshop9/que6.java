package workshop9;
import java.util.*;
public class que6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "Hello World";
	    String[] a = s.split(" ");
	    Stack<String> stack = new Stack<String>();
	    for (String word : a) {
	      stack.push(word);
	    }
	    StringBuilder rs = new StringBuilder();
	    while (!stack.isEmpty()) {
	      rs.append(stack.pop());
	      rs.append(" ");
	    }
	    System.out.println("Reversed sentence: " + rs.toString().trim());
	}

}
