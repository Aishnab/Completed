package workshop9;
import java.util.*;

public class que12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int[] numbers = {5, 3, 8, 4, 2};
		    System.out.println("Original array: " + Arrays.toString(numbers));

		    // Sort the array in ascending order
		    Arrays.sort(numbers);
		    System.out.println("Array sorted in ascending order: " + Arrays.toString(numbers));

		    // Sort the array in descending order
		    for (int i = 0; i < numbers.length / 2; i++) {
		      int temp = numbers[i];
		      numbers[i] = numbers[numbers.length - 1 - i];
		      numbers[numbers.length - 1 - i] = temp;
		    }
		    System.out.println("Array sorted in descending order: " + Arrays.toString(numbers));
	}

}
