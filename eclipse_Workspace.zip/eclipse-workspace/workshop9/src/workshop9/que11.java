package workshop9;
import java.util.*;

public class que11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<String, String> ccapital = new HashMap<String, String>();
	    ccapital.put("Nepal", "Kathmandu");
	    ccapital.put("India", "New Delhi");
	    ccapital.put("United States", "Washington D.C.");
	    ccapital.put("United Kingdom", "London");
	    ccapital.put("Japan", "Tokyo");

	    // Print all the key-value pairs in the HashMap
	    printMap(ccapital);

	    // Get the capital of a country
	    String capital = getCapital(ccapital, "Nepal");
	    System.out.println("Capital of Nepal: " + capital);

	    // Check if a capital exists in the HashMap
	    boolean a = containsCapital(ccapital, "Kathmandu");
	    System.out.println("Does the HashMap contain the capital Kathmandu? " + a);

	    // Print each country and its capital
	    for (String country : ccapital.keySet()) {
	      String capitalName = ccapital.get(country);
	      System.out.println(country + ": " + capitalName);
	    }
	  }

	  public static void printMap(HashMap<String, String> map) {
	    for (String key : map.keySet()) {
	      String value = map.get(key);
	      System.out.println(key + ": " + value);
	    }
	  }

	  public static String getCapital(HashMap<String, String> map, String country) {
	    return map.get(country);
	  }

	  public static boolean containsCapital(HashMap<String, String> map, String capital) {
	    return map.containsValue(capital);
	}

}
