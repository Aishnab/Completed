package workshop9;

import java.util.*;
public class que7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Queue<String> p = new LinkedList<String>();

	    // Enqueue print jobs "Document1", "Document2", and "Document3" into the print queue
	    p.add("Document1");
	    p.add("Document2");
	    p.add("Document3");

	    // Dequeue a print job from the front of the queue
	    String d = p.remove();
	    System.out.println("Dequeued job: " + d);

	    // Enqueue print jobs "Document4" and "Document5" into the print queue
	    p.add("Document4");
	    p.add("Document5");

	    // Peek at the next print job without removing it
	    String nextJob = p.peek();
	    System.out.println("Next job: " + nextJob);

	    // Print the list of print jobs in the queue
	    System.out.println("Print queue: " + p);
	}

}
