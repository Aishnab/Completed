package workshop9;
import java.util.*;

public class que13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> a = new ArrayList<String>();
	    a.add("Red");
	    a.add("Green");
	    a.add("Blue");
	    a.add("Yellow");
	    a.add("Orange");

	    System.out.println("Original list of colors: " + a);

	    // Sort the list in ascending order
	    Collections.sort(a);
	    System.out.println("List sorted in ascending order: " + a);

	    // Sort the list in descending order
	    Collections.sort(a, Collections.reverseOrder());
	    System.out.println("List sorted in descending order: " + a);
	}

}
