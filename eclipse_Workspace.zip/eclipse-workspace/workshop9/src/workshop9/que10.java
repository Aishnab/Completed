package workshop9;
import java.util.*;

public class que10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<String, String> num = new HashMap<String, String>();
	    num.put("Alice", "986010789");
	    num.put("Gina", "984167787");
	    num.put("Aira", "984110700");
	    num.put("Teresa", "986098239");
	    num.put("Eve", "9841344789");

	    System.out.println("Contacts: " + num);
	}

}
