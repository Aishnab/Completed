package workshop9;

import java.util.*;
public class que8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<String> a = new TreeSet<String>();
	    a.add("Alice");
	    a.add("Bob");
	    a.add("Charlie");
	    a.add("David");
	    a.add("Eve");
	    System.out.println("Names in alphabetical order: " + a);
	}

}
