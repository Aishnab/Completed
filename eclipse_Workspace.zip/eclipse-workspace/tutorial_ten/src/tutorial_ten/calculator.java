package tutorial_ten;

public class calculator {

}
