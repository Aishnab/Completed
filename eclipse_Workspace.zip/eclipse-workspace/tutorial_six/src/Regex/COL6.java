package Regex;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class COL6 {
	public static void main (String args[]) {
		String regex="\\D";
		Pattern p = Pattern.compile(regex);
	        
		String userinput = "9";
	    Matcher m = p.matcher(userinput);
	    
	    boolean result = m.matches();
	    System.out.print(result);
	    }
	}


