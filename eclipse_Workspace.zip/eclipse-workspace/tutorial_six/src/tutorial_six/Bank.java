//package tutorial_six;
//
//abstract class BankA{
//
//	void withdraw() {
//		System.out.println("Money Withdrawn.");
//	}
//}
//class Bank1 extends BankA{
//	void deposit() {
//		System.out.println("This is a first subclass.");
//	}
//}
// class Bank2 extends BankA{
//	void deposit() {
//		System.out.println("This is a second subclass.");
//	}
//}
//
//public class Bank {
//	public static void main(String args[]) {
//		Bank1 b1= new Bank1();
//		Bank2 b2= new Bank2();
//		
//		b1.deposit();
//		b2.deposit();			
//	}
//}
