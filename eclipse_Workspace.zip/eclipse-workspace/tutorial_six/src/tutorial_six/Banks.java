package tutorial_six;

abstract class Bank {
    abstract void getbalance();
}
class BankA extends Bank {
    void getbalance() {
        System.out.println("$100");
    }
}

class BankB extends Bank {
    void getbalance() {
        System.out.println("$150");
    }
}

class BankC extends Bank {
    void getbalance() {
        System.out.println("$200");
    }
}

public class Banks {
    public static void main(String[] args) {
        BankA bankA = new BankA(); 
        bankA.getbalance();

        BankB bankB = new BankB(); 
        bankB.getbalance();

        BankC bankC = new BankC(); 
        bankC.getbalance();
    }
}
