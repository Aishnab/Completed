package tutorial_six;
interface Bank{
	void deposit();
	void withdraw();
}
interface NepalBank extends Bank{
	void getBalance();
}
class BankA implements NepalBank{
	
}
public class I_Bank {
public static void main(String args[]) {
	
}
}
